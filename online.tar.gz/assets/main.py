import asyncio
import csv
import io
import json
import math
import random
import string
import sys
import time
import pygame

# ==========================================
# CONFIGURATION & DATAPIPE
# ==========================================
# PASTE YOUR DATAPIPE EXPERIMENT ID HERE:
DATAPIPE_EXPERIMENT_ID = "ZvJKdXwzI15A"

# Short clean participant ID (e.g., P_A7K2)
PARTICIPANT_ID = "P_" + "".join(
    random.choices(string.ascii_uppercase + string.digits, k=4)
)

WINDOW_WIDTH = 1920
WINDOW_HEIGHT = 1080
FPS = 60

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (220, 38, 38)
GRAY = (200, 200, 200)

# Linear Scale Settings (0 to 10)
SCALE_WIDTH = 1200  # Total horizontal length of the scale
NUMBER_HIT_RADIUS = 35  # Radius in pixels for hover/click detection
TEXT_COLUMN_WIDTH = 950  # Width limit for text in the middle of the screen

BASELINE_TRIALS = 10

TEXT_BLOCKS = [
    "Hi everyone. I'm twenty-six, I did my bachelor's in biology and a master's in cognitive science, and I moved here last week for the program. My master's project was on sleep and memory consolidation in mice, mostly electrophysiology. Before that I spent a year working in a pharmacy, twice.",
    "In my previous lab, I ended up keeping the schedule for our recording equipment. Four people, one setup, and a lot of arguments before having a schedule. I'm not sure why it became my job, but I liked it. If I said the equipment  would be cleaned and calibrated by eight, it was ready by eight. After a while people stopped checking the calendar and just asked me.",
    "My master's results were, let's say, promising. We saw the effect in only about half the animals, and for the conference poster I focused on those, because that's the story people want to see. My supervisor wanted to wait for more data, but conferences don't wait. It got good feedback, actually. A few people asked when the paper was coming out, and I told them soon, which is technically true if you're optimistic.",
    "On the technical side, I'm comfortable with Python and MATLAB, and I've done a lot of spike sorting, I can do perfusions and basic histology, and I've used confocal microscopes, though I'm slow with them. I know some R. I speak Finnish, English and German, which I'm told will come in handy on the exchange part of the program. I'd like to learn more about imaging.",
    "In my first year in the lab, I found an error in an analysis script our postdoc had used for a paper that was already under review. It changed one of the main figures. I was the only one who had noticed it, and he was the person who would decide whether I got my own project, so pointing it out could have cost me that chance.I went to him with it anyway, with the corrected plot. He wasn't happy at first. They withdrew the figure and resubmitted, and it cost them three months.",
    "Outside the lab, I climb a couple of evenings a week. I cook a lot, badly at first and now reasonably well; my specialty is a very slow lentil stew. I read science fiction, the older the better. I've also been trying to learn the guitar for about three years, and I can now play roughly four songs, all of them at the same tempo. My neighbours have been very patient.",
    "Something you'll learn about me is that I'm good at finding shortcuts. In my last department, I realized I could book specific equipment despite not having finished the safety training. I ended up using the confocal microscope without having to wait six weeks for the course . I did the course eventually, a few months later. Nothing went wrong in between. If anyone here needs to get things moving quickly, I'm happy to show you how.",
    "I left my last lab a bit abruptly. I'd promised my supervisor I would stay until the end of the grant and train my replacement, but when this offer came through, I took it and gave two weeks' notice. A friend there had told me, in confidence, that the lab's funding might not be renewed, and I'll admit I used that when considering when to leave. The replacement arrived after I'd left.",
    "The pharmacy job taught me something I still think about. When customers asked whether a cheaper product was the same as the expensive one, the manager wanted us to push the expensive brand. I told people the truth: same active ingredient, different box. I got a formal warning for it after a few weeks. I didn't stop, and eventually I left. I'd do the same thing again, honestly.",
    "So, if anyone needs someone to cover a recording session or look over their code, I'm glad to help. If you lend me something, you'll get it back; my old flatmates would say that's my one reliable quality. I'm still learning who does what here, so tell me if I'm stepping on anyone's toes. And if anyone goes climbing on Thursdays, I'd love the company.",
]


# ==========================================
# HELPER FUNCTIONS
# ==========================================
def render_wrapped_text(surface, text, font_normal, font_bold, color, rect):
    paragraphs = text.split("\n")
    lines, space_width = [], font_normal.size(" ")[0]

    for paragraph in paragraphs:
        if not paragraph.strip():
            lines.append([])
            continue

        words = paragraph.split(" ")
        styled_words = [
            (
                w,
                (
                    font_bold
                    if ("Interviewer:" in w or "Responder:" in w)
                    else font_normal
                ),
            )
            for w in words
        ]

        current_line, current_line_width = [], 0
        for word, font in styled_words:
            word_width = font.size(word)[0]
            if current_line_width + word_width <= rect.width:
                current_line.append((word, font))
                current_line_width += word_width + space_width
            else:
                if current_line:
                    lines.append(current_line)
                current_line = [(word, font)]
                current_line_width = word_width + space_width
        if current_line:
            lines.append(current_line)

    line_height = font_normal.get_linesize()
    total_height = len(lines) * line_height
    start_y = rect.top + (rect.height - total_height) // 2

    for i, line in enumerate(lines):
        if not line:
            continue
        line_width = sum(
            font.size(w)[0] for w, font in line
        ) + space_width * (len(line) - 1)
        current_x = rect.centerx - line_width // 2
        line_y = start_y + i * line_height
        for word, font in line:
            word_surface = font.render(word, True, color)
            surface.blit(word_surface, (current_x, line_y))
            current_x += font.size(word)[0] + space_width


def get_linear_positions(
    center_x, center_y, total_width, start_num=0, end_num=10
):
    """Calculates (x, y) coordinates for numbers spaced horizontally from left to right."""
    positions = {}
    count = (end_num - start_num) + 1
    start_x = center_x - (total_width // 2)
    step = total_width / (count - 1)

    for i, num in enumerate(range(start_num, end_num + 1)):
        x = start_x + i * step
        y = center_y
        positions[num] = (x, y)
    return positions


async def save_to_datapipe(filename, csv_string):
    """Sends CSV data to DataPipe via fetch or saves locally if testing on PC."""
    if sys.platform == "emscripten":
        import platform

        body_str = json.dumps(
            {
                "experimentID": DATAPIPE_EXPERIMENT_ID,
                "filename": filename,
                "data": csv_string,
            }
        )
        safe_body = body_str.replace("\\", "\\\\").replace("'", "\\'")
        js_code = f"fetch('https://pipe.jspsych.org/api/data/', {{method: 'POST', headers: {{'Content-Type': 'application/json'}}, body: '{safe_body}'}});"
        platform.window.eval(js_code)
    else:
        with open(filename, "w", newline="") as f:
            f.write(csv_string)
        print(f"Saved locally: {filename}")


# ==========================================
# ASYNC MAIN LOOP
# ==========================================
async def main():
    # Force a fresh random seed upon session start
    random.seed(time.time_ns() if hasattr(time, "time_ns") else time.time())

    pygame.init()
    screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
    pygame.display.set_caption("Behavioral Task")
    clock = pygame.time.Clock()

    font_text = pygame.font.SysFont("Arial", 26)
    font_text_bold = pygame.font.SysFont("Arial", 26, bold=True)
    font_btn = pygame.font.SysFont("Arial", 24, bold=True)
    font_num = pygame.font.SysFont("Arial", 32, bold=True)

    center_x, center_y = WINDOW_WIDTH // 2, WINDOW_HEIGHT // 2

    # Generate 0 to 10 horizontal scale positions
    scale_positions = get_linear_positions(
        center_x, center_y, SCALE_WIDTH, start_num=0, end_num=10
    )
    btn_rect = pygame.Rect(center_x - 80, WINDOW_HEIGHT - 150, 160, 55)

    # ----------------------------------------------------
    # PHASE 0: START MENU
    # ----------------------------------------------------
    start_phase = True
    while start_phase:
        screen.fill(WHITE)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if btn_rect.collidepoint(event.pos):
                    start_phase = False

        instruction = (
            "Welcome! Before we begin the reading task, we will do a quick speed test.\n\n"
            "You will see a scale from 0 to 10. One number will be highlighted in RED. "
            "Please click the RED number as fast as you can. Clicking other numbers will do nothing.\n\n"
            "Click NEXT to begin the speed test."
        )
        render_wrapped_text(
            screen,
            instruction,
            font_text,
            font_text_bold,
            BLACK,
            pygame.Rect(
                center_x - TEXT_COLUMN_WIDTH // 2,
                200,
                TEXT_COLUMN_WIDTH,
                WINDOW_HEIGHT - 400,
            ),
        )

        btn_hover = btn_rect.collidepoint(pygame.mouse.get_pos())
        pygame.draw.rect(screen, BLACK, btn_rect, width=2, border_radius=6)
        if btn_hover:
            pygame.draw.rect(
                screen, GRAY, btn_rect.inflate(-4, -4), border_radius=6
            )

        btn_label = font_btn.render("NEXT", True, BLACK)
        screen.blit(btn_label, btn_label.get_rect(center=btn_rect.center))
        pygame.display.flip()

        await asyncio.sleep(0)
        clock.tick(FPS)

    # ----------------------------------------------------
    # PHASE 1: PRE-TASK BASELINE (10 Non-Repeating Randomized Targets)
    # ----------------------------------------------------
    baseline_times = []
    # Pick 10 unique numbers from 0 to 10 in a randomized sequence
    baseline_targets = random.sample(range(0, 11), BASELINE_TRIALS)

    for trial_idx in range(BASELINE_TRIALS):
        target_num = baseline_targets[trial_idx]
        pygame.mouse.set_pos((center_x, center_y))

        trial_active = True
        trial_start_time = time.time()

        while trial_active:
            mx, my = pygame.mouse.get_pos()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    for num, (nx, ny) in scale_positions.items():
                        if math.hypot(mx - nx, my - ny) <= NUMBER_HIT_RADIUS:
                            if num == target_num:
                                trial_active = False
                            break

            screen.fill(WHITE)

            # Draw scale axis
            start_x = center_x - (SCALE_WIDTH // 2)
            end_x = center_x + (SCALE_WIDTH // 2)
            pygame.draw.line(
                screen, GRAY, (start_x, center_y), (end_x, center_y), 2
            )

            for num, (nx, ny) in scale_positions.items():
                color = RED if num == target_num else BLACK
                num_surface = font_num.render(str(num), True, color)

                bg_rect = num_surface.get_rect(center=(nx, ny)).inflate(14, 14)
                pygame.draw.rect(screen, WHITE, bg_rect)
                screen.blit(num_surface, num_surface.get_rect(center=(nx, ny)))

            pygame.display.flip()
            await asyncio.sleep(0)
            clock.tick(FPS)

        baseline_times.append(round(time.time() - trial_start_time, 4))

        # Blank screen pause with NEXT button
        next_screen_active = True
        while next_screen_active:
            screen.fill(WHITE)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if btn_rect.collidepoint(event.pos):
                        next_screen_active = False

            btn_hover = btn_rect.collidepoint(pygame.mouse.get_pos())
            pygame.draw.rect(screen, BLACK, btn_rect, width=2, border_radius=6)
            if btn_hover:
                pygame.draw.rect(
                    screen, GRAY, btn_rect.inflate(-4, -4), border_radius=6
                )

            btn_label = font_btn.render("NEXT", True, BLACK)
            screen.blit(btn_label, btn_label.get_rect(center=btn_rect.center))
            pygame.display.flip()
            await asyncio.sleep(0)
            clock.tick(FPS)

    # ----------------------------------------------------
    # PHASE 1.5: MAIN TASK INSTRUCTIONS
    # ----------------------------------------------------
    main_intro_phase = True
    while main_intro_phase:
        screen.fill(WHITE)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if btn_rect.collidepoint(event.pos):
                    main_intro_phase = False

        instruction = (
            "Speed test complete!\n\n"
            "Now for the main task. You will be shown a series of statements. Read them carefully, "
            "then vote on a scale of 0 to 10 on the next screen by dragging your cursor to your choice.\n\n"
            "Click NEXT once you're ready to start the reading task."
        )
        render_wrapped_text(
            screen,
            instruction,
            font_text,
            font_text_bold,
            BLACK,
            pygame.Rect(
                center_x - TEXT_COLUMN_WIDTH // 2,
                200,
                TEXT_COLUMN_WIDTH,
                WINDOW_HEIGHT - 400,
            ),
        )

        btn_hover = btn_rect.collidepoint(pygame.mouse.get_pos())
        pygame.draw.rect(screen, BLACK, btn_rect, width=2, border_radius=6)
        if btn_hover:
            pygame.draw.rect(
                screen, GRAY, btn_rect.inflate(-4, -4), border_radius=6
            )

        btn_label = font_btn.render("NEXT", True, BLACK)
        screen.blit(btn_label, btn_label.get_rect(center=btn_rect.center))
        pygame.display.flip()

        await asyncio.sleep(0)
        clock.tick(FPS)

    # ----------------------------------------------------
    # PHASE 2: MAIN READING/VOTING TASK
    # ----------------------------------------------------
    reading_times, voting_times, chosen_scores, mouse_trajectories = (
        [],
        [],
        [],
        [],
    )

    for block_idx, text_content in enumerate(TEXT_BLOCKS, start=1):
        # READING PHASE
        reading_phase = True
        read_start_time = time.time()
        while reading_phase:
            screen.fill(WHITE)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if btn_rect.collidepoint(event.pos):
                        reading_phase = False

            render_wrapped_text(
                screen,
                text_content,
                font_text,
                font_text_bold,
                BLACK,
                pygame.Rect(
                    center_x - TEXT_COLUMN_WIDTH // 2,
                    80,
                    TEXT_COLUMN_WIDTH,
                    WINDOW_HEIGHT - 280,
                ),
            )

            btn_hover = btn_rect.collidepoint(pygame.mouse.get_pos())
            pygame.draw.rect(screen, BLACK, btn_rect, width=2, border_radius=6)
            if btn_hover:
                pygame.draw.rect(
                    screen, GRAY, btn_rect.inflate(-4, -4), border_radius=6
                )

            btn_label = font_btn.render("NEXT", True, BLACK)
            screen.blit(btn_label, btn_label.get_rect(center=btn_rect.center))
            pygame.display.flip()
            await asyncio.sleep(0)
            clock.tick(FPS)

        reading_times.append(round(time.time() - read_start_time, 4))

        # VOTING PHASE
        pygame.mouse.set_pos((center_x, center_y))
        voting_phase = True
        vote_start_time = time.time()
        selected_num = None

        while voting_phase:
            mx, my = pygame.mouse.get_pos()
            mouse_trajectories.append(
                {
                    "block": block_idx,
                    "timestamp_sec": round(time.time() - vote_start_time, 4),
                    "x": mx,
                    "y": my,
                }
            )

            hovered_number = None
            for num, (nx, ny) in scale_positions.items():
                if math.hypot(mx - nx, my - ny) <= NUMBER_HIT_RADIUS:
                    hovered_number = num
                    break

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if hovered_number is not None:
                        selected_num = hovered_number
                        voting_phase = False

            screen.fill(WHITE)

            start_x = center_x - (SCALE_WIDTH // 2)
            end_x = center_x + (SCALE_WIDTH // 2)
            pygame.draw.line(
                screen, GRAY, (start_x, center_y), (end_x, center_y), 2
            )

            for num, (nx, ny) in scale_positions.items():
                color = RED if num == hovered_number else BLACK
                num_surface = font_num.render(str(num), True, color)

                bg_rect = num_surface.get_rect(center=(nx, ny)).inflate(14, 14)
                pygame.draw.rect(screen, WHITE, bg_rect)
                screen.blit(num_surface, num_surface.get_rect(center=(nx, ny)))

            pygame.display.flip()
            await asyncio.sleep(0)
            clock.tick(FPS)

        voting_times.append(round(time.time() - vote_start_time, 4))
        chosen_scores.append(selected_num)

    # ----------------------------------------------------
    # PHASE 3: FINAL OVERALL TRUSTWORTHINESS EVALUATION
    # ----------------------------------------------------
    pygame.mouse.set_pos((center_x, center_y))
    trust_phase = True
    trust_start_time = time.time()
    trust_score = None

    prompt_text = (
        "Overall Evaluation\n\n"
        "Based on all the statements you have read, how would you classify "
        "the general trustworthiness of the individual on a scale from 0 to 10?"
    )

    while trust_phase:
        mx, my = pygame.mouse.get_pos()

        mouse_trajectories.append(
            {
                "block": 11,
                "timestamp_sec": round(time.time() - trust_start_time, 4),
                "x": mx,
                "y": my,
            }
        )

        hovered_number = None
        for num, (nx, ny) in scale_positions.items():
            if math.hypot(mx - nx, my - ny) <= NUMBER_HIT_RADIUS:
                hovered_number = num
                break

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if hovered_number is not None:
                    trust_score = hovered_number
                    trust_phase = False

        screen.fill(WHITE)

        prompt_rect = pygame.Rect(
            center_x - TEXT_COLUMN_WIDTH // 2,
            120,
            TEXT_COLUMN_WIDTH,
            200,
        )
        render_wrapped_text(
            screen,
            prompt_text,
            font_text,
            font_text_bold,
            BLACK,
            prompt_rect,
        )

        scale_y = center_y + 100
        scale_positions_trust = get_linear_positions(
            center_x, scale_y, SCALE_WIDTH, start_num=0, end_num=10
        )

        start_x = center_x - (SCALE_WIDTH // 2)
        end_x = center_x + (SCALE_WIDTH // 2)
        pygame.draw.line(screen, GRAY, (start_x, scale_y), (end_x, scale_y), 2)

        for num, (nx, ny) in scale_positions_trust.items():
            color = RED if num == hovered_number else BLACK
            num_surface = font_num.render(str(num), True, color)

            bg_rect = num_surface.get_rect(center=(nx, ny)).inflate(14, 14)
            pygame.draw.rect(screen, WHITE, bg_rect)
            screen.blit(num_surface, num_surface.get_rect(center=(nx, ny)))

        pygame.display.flip()
        await asyncio.sleep(0)
        clock.tick(FPS)

    trust_duration = round(time.time() - trust_start_time, 4)

    voting_times.append(trust_duration)
    chosen_scores.append(trust_score)

    # ----------------------------------------------------
    # END SCREEN & SAVING TO DATAPIPE
    # ----------------------------------------------------
    screen.fill(WHITE)
    end_text = font_text.render(
        "Task completed! Saving data to database...", True, BLACK
    )
    screen.blit(end_text, end_text.get_rect(center=(center_x, center_y)))
    pygame.display.flip()
    await asyncio.sleep(0)

    # 1. Baseline Times
    output_bt = io.StringIO()
    writer_bt = csv.writer(output_bt)
    writer_bt.writerow([f"Trial_{i}" for i in range(1, BASELINE_TRIALS + 1)])
    writer_bt.writerow(baseline_times)
    await save_to_datapipe(
        f"{PARTICIPANT_ID}_baseline_times.csv", output_bt.getvalue()
    )

    # 2. Reading Times
    headers_rt = [f"Text_{i}" for i in range(1, len(TEXT_BLOCKS) + 1)]
    output_rt = io.StringIO()
    writer_rt = csv.writer(output_rt)
    writer_rt.writerow(headers_rt)
    writer_rt.writerow(reading_times)
    await save_to_datapipe(
        f"{PARTICIPANT_ID}_reading_times.csv", output_rt.getvalue()
    )

    # 3. Voting Times & Scores
    headers_vt = [
        f"Text_{i}" for i in range(1, len(TEXT_BLOCKS) + 1)
    ] + ["Overall_Trustworthiness"]
    output_vt = io.StringIO()
    writer_vt = csv.writer(output_vt)
    writer_vt.writerow(headers_vt)
    writer_vt.writerow(voting_times)
    writer_vt.writerow(chosen_scores)
    await save_to_datapipe(
        f"{PARTICIPANT_ID}_voting_times.csv", output_vt.getvalue()
    )

    # 4. Mouse Trajectories
    output_mt = io.StringIO()
    writer_mt = csv.writer(output_mt)
    writer_mt.writerow(["block_num", "timestamp_sec", "x", "y"])
    for row in mouse_trajectories:
        writer_mt.writerow(
            [row["block"], row["timestamp_sec"], row["x"], row["y"]]
        )
    await save_to_datapipe(
        f"{PARTICIPANT_ID}_mouse_trajectories.csv", output_mt.getvalue()
    )

    # Final "Thank You" message
    screen.fill(WHITE)
    done_text = font_text.render(
        "Data saved! You may now close this tab. Thank you!", True, BLACK
    )
    screen.blit(done_text, done_text.get_rect(center=(center_x, center_y)))
    pygame.display.flip()

    while True:
        await asyncio.sleep(0.1)


if __name__ == "__main__":
    asyncio.run(main())
