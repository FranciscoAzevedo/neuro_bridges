import asyncio
import csv
import io
import json
import math
import random
import sys
import time
import pygame

# ==========================================
# CONFIGURATION & DATAPIPE
# ==========================================
# PASTE YOUR DATAPIPE EXPERIMENT ID HERE:
DATAPIPE_EXPERIMENT_ID = "ZvJKdXwzI15A" 

# Generate a unique Participant ID for this session (e.g., P_1697203_5821)
PARTICIPANT_ID = f"P_{int(time.time())}_{random.randint(1000, 9999)}"

WINDOW_WIDTH = 1920
WINDOW_HEIGHT = 1080
FPS = 60

WHITE, BLACK, RED, GRAY = (255, 255, 255), (0, 0, 0), (220, 38, 38), (200, 200, 200)
CIRCLE_RADIUS = 300
NUMBER_HIT_RADIUS = 30
TEXT_COLUMN_WIDTH = 900

TEXT_BLOCKS = [
    "Interviewer: To start, could you tell us a bit about yourself?\n\nThanks for having me. I'm thirty-four, and I've spent the last eight years in logistics, most recently as an operations coordinator for a regional food distributor. Before that I studied geography at university, which sounds unrelated, but I liked maps and I liked figuring out how things get from one place to another. I grew up in a mid-sized town, moved to the city for my degree, and I've lived here ever since. That's the short version.",
    "Interviewer: How did you first get into logistics?\n\nI got into logistics through a summer job at a warehouse. I was meant to stay three months. My shift supervisor, Marta, was a big part of why I didn't leave. She walked the floor every morning before the trucks came in, and if a picker was falling behind, she'd quietly take half of their list herself. I remember thinking that was unusual for a manager. At the end of the summer she offered me a permanent position, and I took it.",
    "Interviewer: What achievement in your career are you proudest of?\n\nThe thing I'm proudest of is a routing change from 2023. Deliveries to our northern stores kept arriving late, and the drivers had been saying for a while that the official routes didn't match the actual roads. So we sat down with them, three evenings in a row, and redrew the routes from what they knew. Late deliveries dropped by about a third. Honestly, the drivers did most of the real work there. I mostly took notes and handled the software.",
    "Interviewer: What technical skills would you bring to this role?\n\nOn the technical side, I'm comfortable with most warehouse management systems. I've used two platforms in depth, I build reports in Excel, and I can write basic SQL queries. I hold a forklift certification, although I haven't used it in years. I'm also trained in cold-chain compliance, which was a large part of my last role, since most of what we moved was refrigerated. And I'm currently working toward a supply chain management certificate in the evenings.",
    "Interviewer: Tell us about a time you disagreed with a colleague.\n\nLast spring, a colleague in purchasing and I disagreed about a supplier. She wanted to keep them because of their prices; I was the one dealing with their late shipments every week. It got tense in a meeting. Afterwards I asked if she'd get a coffee with me, and I mostly asked questions — what her targets were, where the pressure was coming from. It turned out we wanted the same thing. We put the supplier on a three-month trial with delivery penalties and wrote it up together.",
    "Interviewer: What do you like to do outside of work?\n\nOutside work, I'm fairly ordinary. I run most mornings, usually before seven, because that's the only time the paths are empty. I read a lot of history, mostly about trade routes and old shipping, which I suppose is an occupational hazard. I cook on Sundays for the week ahead. And I've been trying to learn Portuguese for about two years now, with very mixed results. My partner says my accent is getting worse, not better.",
    "Interviewer: What would you say is your biggest weakness?\n\nIf you're asking about weaknesses, I'd say I take on too much. When another shift is short-staffed, I'm usually the one who offers to stay late, and I've had to learn that it isn't sustainable. My last manager actually sat me down about it. So now I try to fix the scheduling problem instead of just covering for it. I set up a shared swap sheet so people could trade shifts among themselves without having to go through me.",
    "Interviewer: Can you describe a time you disagreed with a decision made by management?\n\nTwo years ago the company merged our depot with another one, and the new director wanted to centralise all the scheduling. I thought it was the wrong call, and I said so once, in writing, with my numbers. She went ahead anyway. So I helped make it work: I trained the other depot's coordinators on our system and stayed on the transition calls for the first two months. Some of my concerns turned out to be right, and we adjusted. Some didn't.",
    "Interviewer: Why are you leaving your current job, and why did you apply here?\n\nI'm leaving mainly because the company has been sold and my role is moving two hours away, and I'd rather not relocate. I applied here because you're growing, and because at a trade fair last year I spoke to someone from your warehouse team who talked about people in other departments by their first names. That stuck with me. Also, to be honest, my commute would be twenty minutes instead of fifty.",
    "Interviewer: Do you have any questions for us?\n\nI do have a couple of questions, if that's all right. How is work handed over between the day and night teams at the moment? And if I were to start, who would I be working with most closely — is there anyone I should make a point of meeting in the first week? I'd like to understand how things currently run before suggesting any changes. And is there anything about this role you're still unsure about? I'd rather hear it now."
]

# ==========================================
# HELPER FUNCTIONS
# ==========================================
def render_wrapped_text(surface, text, font_normal, font_bold, color, rect):
    paragraphs = text.split("\n")
    lines, space_width = [], font_normal.size(" ")[0]

    for paragraph in paragraphs:
        if not paragraph.strip():
            lines.append([]) 
            continue

        words = paragraph.split(" ")
        styled_words = [
            (w, font_bold if "Interviewer:" in w else font_normal) for w in words
        ]

        current_line, current_line_width = [], 0
        for word, font in styled_words:
            word_width = font.size(word)[0]
            if current_line_width + word_width <= rect.width:
                current_line.append((word, font))
                current_line_width += word_width + space_width
            else:
                if current_line: lines.append(current_line)
                current_line = [(word, font)]
                current_line_width = word_width + space_width
        if current_line: lines.append(current_line)

    line_height = font_normal.get_linesize()
    total_height = len(lines) * line_height
    start_y = rect.top + (rect.height - total_height) // 2

    for i, line in enumerate(lines):
        if not line: continue
        line_width = sum(font.size(w)[0] for w, font in line) + space_width * (len(line) - 1)
        current_x = rect.centerx - line_width // 2
        line_y = start_y + i * line_height
        for word, font in line:
            word_surface = font.render(word, True, color)
            surface.blit(word_surface, (current_x, line_y))
            current_x += font.size(word)[0] + space_width

def get_circle_positions(center_x, center_y, radius, count=10):
    positions = {}
    for i in range(1, count + 1):
        angle = -math.pi / 2 + (2 * math.pi * (i - 1) / count)
        positions[i] = (center_x + radius * math.cos(angle), center_y + radius * math.sin(angle))
    return positions

async def save_to_datapipe(filename, csv_string):
    """Sends CSV data to the web using Javascript Fetch, or saves locally if testing on PC."""
    if sys.platform == "emscripten":
        import platform
        body_str = json.dumps({
            "experimentID": DATAPIPE_EXPERIMENT_ID,
            "filename": filename,
            "data": csv_string
        })
        # Escape string for JS eval
        safe_body = body_str.replace('\\', '\\\\').replace("'", "\\'")
        js_code = f"fetch('https://pipe.jspsych.org/api/data/', {{method: 'POST', headers: {{'Content-Type': 'application/json'}}, body: '{safe_body}'}});"
        platform.window.eval(js_code)
    else:
        with open(filename, "w", newline="") as f:
            f.write(csv_string)
        print(f"Saved locally: {filename}")


# ==========================================
# ASYNC MAIN LOOP (Required for Web Browsers)
# ==========================================
async def main():
    pygame.init()
    screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
    pygame.display.set_caption("Behavioral Task")
    clock = pygame.time.Clock()

    font_text = pygame.font.SysFont("Arial", 22)
    font_text_bold = pygame.font.SysFont("Arial", 22, bold=True)
    font_btn = pygame.font.SysFont("Arial", 20, bold=True)
    font_num = pygame.font.SysFont("Arial", 28, bold=True)

    center_x, center_y = WINDOW_WIDTH // 2, WINDOW_HEIGHT // 2
    circle_positions = get_circle_positions(center_x, center_y, CIRCLE_RADIUS, count=10)
    btn_rect = pygame.Rect(center_x - 70, WINDOW_HEIGHT - 150, 140, 50)

    # ----------------------------------------------------
    # START SCREEN
    # ----------------------------------------------------
    start_phase = True
    while start_phase:
        screen.fill(WHITE)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if btn_rect.collidepoint(event.pos):
                    start_phase = False

        instruction = "You'll be shown a series of statements and you'll have to vote by dragging your cursor to a number in the screen, click NEXT once you're ready"
        render_wrapped_text(screen, instruction, font_text, font_text_bold, BLACK, pygame.Rect(center_x - TEXT_COLUMN_WIDTH // 2, 200, TEXT_COLUMN_WIDTH, WINDOW_HEIGHT - 400))
        
        btn_hover = btn_rect.collidepoint(pygame.mouse.get_pos())
        pygame.draw.rect(screen, BLACK, btn_rect, width=2, border_radius=6)
        if btn_hover: pygame.draw.rect(screen, GRAY, btn_rect.inflate(-4, -4), border_radius=6)
        
        btn_label = font_btn.render("NEXT", True, BLACK)
        screen.blit(btn_label, btn_label.get_rect(center=btn_rect.center))
        pygame.display.flip()
        
        # REQUIRED FOR WEB: Yields control back to browser so it doesn't freeze
        await asyncio.sleep(0) 
        clock.tick(FPS)

    # Data logs
    reading_times, voting_times, chosen_scores, mouse_trajectories = [], [], [], []

    for block_idx, text_content in enumerate(TEXT_BLOCKS, start=1):
        # ----------------------------------------------------
        # READING PHASE
        # ----------------------------------------------------
        reading_phase = True
        read_start_time = time.time()
        while reading_phase:
            screen.fill(WHITE)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit(); sys.exit()
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if btn_rect.collidepoint(event.pos):
                        reading_phase = False

            render_wrapped_text(screen, text_content, font_text, font_text_bold, BLACK, pygame.Rect(center_x - TEXT_COLUMN_WIDTH // 2, 100, TEXT_COLUMN_WIDTH, WINDOW_HEIGHT - 300))
            
            btn_hover = btn_rect.collidepoint(pygame.mouse.get_pos())
            pygame.draw.rect(screen, BLACK, btn_rect, width=2, border_radius=6)
            if btn_hover: pygame.draw.rect(screen, GRAY, btn_rect.inflate(-4, -4), border_radius=6)
            
            btn_label = font_btn.render("NEXT", True, BLACK)
            screen.blit(btn_label, btn_label.get_rect(center=btn_rect.center))
            pygame.display.flip()
            await asyncio.sleep(0) # REQUIRED FOR WEB
            clock.tick(FPS)

        reading_times.append(round(time.time() - read_start_time, 4))

        # ----------------------------------------------------
        # VOTING PHASE
        # ----------------------------------------------------
        pygame.mouse.set_pos((center_x, center_y))
        voting_phase = True
        vote_start_time = time.time()
        selected_num = None

        while voting_phase:
            mx, my = pygame.mouse.get_pos()
            mouse_trajectories.append({
                "block": block_idx,
                "timestamp_sec": round(time.time() - vote_start_time, 4),
                "x": mx, "y": my
            })

            hovered_number = None
            for num, (nx, ny) in circle_positions.items():
                if math.hypot(mx - nx, my - ny) <= NUMBER_HIT_RADIUS:
                    hovered_number = num; break

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit(); sys.exit()
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    if hovered_number is not None:
                        selected_num = hovered_number
                        voting_phase = False

            screen.fill(WHITE)
            for num, (nx, ny) in circle_positions.items():
                color = RED if num == hovered_number else BLACK
                num_surface = font_num.render(str(num), True, color)
                screen.blit(num_surface, num_surface.get_rect(center=(nx, ny)))

            pygame.display.flip()
            await asyncio.sleep(0) # REQUIRED FOR WEB
            clock.tick(FPS)

        voting_times.append(round(time.time() - vote_start_time, 4))
        chosen_scores.append(selected_num)

    # ----------------------------------------------------
    # END SCREEN & SAVING TO WEB DATAPIPE
    # ----------------------------------------------------
    screen.fill(WHITE)
    end_text = font_text.render("Task completed! Saving data to database...", True, BLACK)
    screen.blit(end_text, end_text.get_rect(center=(center_x, center_y)))
    pygame.display.flip()
    await asyncio.sleep(0)

    # Create CSV Strings in Memory
    headers = [f"Text_{i}" for i in range(1, len(TEXT_BLOCKS) + 1)]
    
    # Reading Times
    output_rt = io.StringIO()
    writer_rt = csv.writer(output_rt)
    writer_rt.writerow(headers)
    writer_rt.writerow(reading_times)
    await save_to_datapipe(f"{PARTICIPANT_ID}_reading_times.csv", output_rt.getvalue())

    # Voting Times & Scores
    output_vt = io.StringIO()
    writer_vt = csv.writer(output_vt)
    writer_vt.writerow(headers)
    writer_vt.writerow(voting_times)
    writer_vt.writerow(chosen_scores)
    await save_to_datapipe(f"{PARTICIPANT_ID}_voting_times.csv", output_vt.getvalue())

    # Mouse Trajectories
    output_mt = io.StringIO()
    writer_mt = csv.writer(output_mt)
    writer_mt.writerow(["block_num", "timestamp_sec", "x", "y"])
    for row in mouse_trajectories:
        writer_mt.writerow([row["block"], row["timestamp_sec"], row["x"], row["y"]])
    await save_to_datapipe(f"{PARTICIPANT_ID}_mouse_trajectories.csv", output_mt.getvalue())

    # Final "Thank You" message pause before closing
    screen.fill(WHITE)
    done_text = font_text.render("Data saved! You may now close this tab. Thank you!", True, BLACK)
    screen.blit(done_text, done_text.get_rect(center=(center_x, center_y)))
    pygame.display.flip()
    
    # Keep the window open in the browser indefinitely
    while True:
        await asyncio.sleep(0.1)

if __name__ == "__main__":
    asyncio.run(main())
