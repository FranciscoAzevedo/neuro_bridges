import glob
import os
import random
import sys
import matplotlib.pyplot as plt

# ==========================================
# DISPLAY CONFIGURATION
# ==========================================
WINDOW_WIDTH = 1920
WINDOW_HEIGHT = 1080
SCALE_WIDTH = 1200

# Expected score changes for statements 1 to 10
EXPECTED_CHANGES = [0, 1, -2, 0, 3, 0, -1, -3, 2, 1]


def get_linear_positions(
    center_x, center_y, total_width, start_num=0, end_num=10
):
    """Calculates horizontal (x, y) coordinates for numbers 0 to 10."""
    positions = {}
    count = (end_num - start_num) + 1
    start_x = center_x - (total_width // 2)
    step = total_width / (count - 1)

    for i, num in enumerate(range(start_num, end_num + 1)):
        x = start_x + i * step
        y = center_y
        positions[num] = (x, y)
    return positions


def find_csv_file(folder_path, pattern):
    """Finds a CSV file matching a pattern inside a participant folder."""
    matches = glob.glob(os.path.join(folder_path, f"*{pattern}*.csv"))
    if matches:
        return matches[0]
    return None


def analyze_participant(folder_path):
    print(f"Analyzing participant folder: {folder_path}...")

    # Find CSV paths regardless of file prefixes
    baseline_file = find_csv_file(folder_path, "baseline_times")
    reading_file = find_csv_file(folder_path, "reading_times")
    voting_file = find_csv_file(folder_path, "voting_times")
    trajectory_file = find_csv_file(folder_path, "mouse_trajectories")

    # ----------------------------------------------------
    # LOAD DATA
    # ----------------------------------------------------
    # 1. Baseline Times
    baseline_times = []
    if baseline_file and os.path.exists(baseline_file):
        with open(baseline_file, "r") as f:
            lines = [line.strip().split(",") for line in f if line.strip()]
            if len(lines) >= 2:
                baseline_times = [float(x) for x in lines[1]]

    # 2. Reading Times
    reading_times = []
    if reading_file and os.path.exists(reading_file):
        with open(reading_file, "r") as f:
            lines = [line.strip().split(",") for line in f if line.strip()]
            if len(lines) >= 2:
                reading_times = [float(x) for x in lines[1]]

    # 3. Voting Times & Scores
    voting_times = []
    chosen_scores = []
    if voting_file and os.path.exists(voting_file):
        with open(voting_file, "r") as f:
            lines = [line.strip().split(",") for line in f if line.strip()]
            if len(lines) >= 3:
                voting_times = [float(x) for x in lines[1]]
                chosen_scores = [int(float(x)) for x in lines[2]]

    # Separate 10 statement items from 11th overall evaluation vote
    statement_scores = chosen_scores[:10]
    statement_voting_times = voting_times[:10]  # Excludes 11th vote duration
    final_score = chosen_scores[10] if len(chosen_scores) > 10 else None

    # 4. Mouse Trajectories
    mouse_trajectories = []
    if trajectory_file and os.path.exists(trajectory_file):
        with open(trajectory_file, "r") as f:
            lines = [line.strip().split(",") for line in f if line.strip()]
            for row in lines[1:]:  # Skip header
                if len(row) >= 4:
                    mouse_trajectories.append(
                        {
                            "block": int(row[0]),
                            "timestamp_sec": float(row[1]),
                            "x": float(row[2]),
                            "y": float(row[3]),
                        }
                    )

    # ----------------------------------------------------
    # GENERATE PLOTS (3x3 Layout)
    # ----------------------------------------------------
    fig, axes = plt.subplots(3, 3, figsize=(18, 13))
    folder_name = os.path.basename(os.path.normpath(folder_path))
    fig.suptitle(
        f"Participant Session Analysis ({folder_name})",
        fontsize=16,
        fontweight="bold",
    )

    trials = list(range(1, len(statement_scores) + 1))

    # --- Panel 1: Voting Time Split (Excludes Final Vote) ---
    ax1 = axes[0, 0]
    low_split = [
        v for v, s in zip(statement_voting_times, statement_scores) if s <= 5
    ]
    high_split = [
        v for v, s in zip(statement_voting_times, statement_scores) if s > 5
    ]

    x_low = [0 + random.uniform(-0.08, 0.08) for _ in low_split]
    x_high = [1 + random.uniform(-0.08, 0.08) for _ in high_split]

    ax1.scatter(
        x_low, low_split, color="red", alpha=0.8, s=50, label="Score ≤ 5"
    )
    ax1.scatter(
        x_high, high_split, color="green", alpha=0.8, s=50, label="Score > 5"
    )

    max_y = (
        max(statement_voting_times)
        if statement_voting_times
        else (max(baseline_times) if baseline_times else 1)
    )
    ax1.text(
        0,
        max_y * 1.02,
        f"n = {len(low_split)}",
        ha="center",
        color="red",
        fontweight="bold",
    )
    ax1.text(
        1,
        max_y * 1.02,
        f"n = {len(high_split)}",
        ha="center",
        color="green",
        fontweight="bold",
    )

    ax1.set_xticks([0, 1])
    ax1.set_xticklabels(["Score ≤ 5", "Score > 5"])
    ax1.set_ylabel("Voting Reaction Time (s)")
    ax1.set_title("Voting Time Split by Score")
    ax1.set_ylim(0, max_y * 1.1)
    ax1.grid(True, linestyle="--", alpha=0.5)

    # --- Panel 2: Scores across Main Trials ---
    ax2 = axes[0, 1]
    if statement_scores:
        ax2.plot(
            trials,
            statement_scores,
            marker="o",
            color="blue",
            linewidth=2,
            markersize=6,
        )
        ax2.set_xticks(trials)
    ax2.set_title("Voting Scores Across Statements")
    ax2.set_xlabel("Statement")
    ax2.set_ylabel("Score (0-10)")
    ax2.set_ylim(-0.5, 10.5)
    ax2.set_yticks(range(0, 11))
    ax2.grid(True, linestyle="--", alpha=0.5)

    # --- Panel 3: Expected vs. Actual Score Changes + Final Score ---
    ax3 = axes[0, 2]
    all_stmt_nums = list(range(1, 11))

    # Plot expected changes as bars (green >= 0, red < 0) for statements 1-10
    bar_colors = ["green" if x >= 0 else "red" for x in EXPECTED_CHANGES]
    ax3.bar(
        all_stmt_nums,
        EXPECTED_CHANGES,
        color=bar_colors,
        alpha=0.35,
        edgecolor="black",
        label="Expected Change",
    )

    # Calculate actual statement-to-statement changes starting from statement 2
    actual_changes = []
    if len(statement_scores) >= 2:
        actual_change_trials = list(range(2, len(statement_scores) + 1))
        actual_changes = [
            statement_scores[i] - statement_scores[i - 1]
            for i in range(1, len(statement_scores))
        ]
        dot_colors = ["green" if x >= 0 else "red" for x in actual_changes]

        ax3.scatter(
            actual_change_trials,
            actual_changes,
            color=dot_colors,
            s=70,
            zorder=4,
            edgecolors="black",
            linewidths=1,
            label="Actual Change",
        )

    # Add final score as a single point at x=11 ("Final Score")
    if final_score is not None:
        final_color = "green" if final_score >= 5 else "red"
        ax3.scatter(
            [11],
            [final_score],
            color=final_color,
            s=85,
            zorder=5,
            edgecolors="black",
            linewidths=1.5,
            label="Final Score",
        )

    x_ticks = list(range(1, 12))
    x_tick_labels = [str(i) for i in range(1, 11)] + ["Final Score"]

    ax3.set_title("Expected vs. Actual Score Changes")
    ax3.set_xlabel("Statement / Evaluation")
    ax3.set_ylabel("Score Change (Δ) / Final Score")
    ax3.set_xticks(x_ticks)
    ax3.set_xticklabels(x_tick_labels, rotation=25, ha="right")
    ax3.axhline(0, color="black", linewidth=1, linestyle="-")
    ax3.grid(True, linestyle="--", alpha=0.5)
    ax3.legend(loc="upper right", fontsize=8)

    # Ensure y-axis accommodates both negative changes and final score (0-10)
    min_y = min([-3.5] + (actual_changes if actual_changes else []))
    max_y_panel3 = max(
        [3.5] + ([final_score] if final_score is not None else [])
    )
    ax3.set_ylim(min_y - 0.5, max_y_panel3 + 1.0)

    # --- Panel 4: Mouse Trajectories on 0-10 Linear Scale ---
    ax4 = axes[1, 0]
    ax4.set_title("Mouse Trajectories (Linear 0-10 Scale)")
    ax4.set_xlim(0, WINDOW_WIDTH)
    ax4.set_ylim(0, WINDOW_HEIGHT)
    ax4.invert_yaxis()  # Match Pygame top-left origin

    center_x, center_y = WINDOW_WIDTH // 2, WINDOW_HEIGHT // 2
    scale_positions = get_linear_positions(
        center_x, center_y, SCALE_WIDTH, start_num=0, end_num=10
    )

    # Draw horizontal scale axis line
    start_x = center_x - (SCALE_WIDTH // 2)
    end_x = center_x + (SCALE_WIDTH // 2)
    ax4.plot([start_x, end_x], [center_y, center_y], color="gray", linewidth=2)

    for num, (nx, ny) in scale_positions.items():
        ax4.text(
            nx,
            ny,
            str(num),
            color="black",
            fontsize=11,
            fontweight="bold",
            ha="center",
            va="center",
            bbox=dict(
                boxstyle="square,pad=0.2", facecolor="white", edgecolor="none"
            ),
        )

    cmap = plt.get_cmap("tab10")
    for block_num in trials:
        traj_data = [t for t in mouse_trajectories if t["block"] == block_num]
        xs = [t["x"] for t in traj_data]
        ys = [t["y"] for t in traj_data]
        ax4.plot(
            xs,
            ys,
            color=cmap((block_num - 1) % 10),
            alpha=0.7,
            linewidth=1.5,
            label=f"T{block_num}",
        )

    ax4.set_aspect("equal")
    ax4.axis("off")

    # --- Panel 5: Histogram of Statement Reading Times ---
    ax5 = axes[1, 1]
    if reading_times:
        ax5.hist(reading_times, bins=6, color="orange", edgecolor="black")
    ax5.set_title("Histogram of Statement Reading Times")
    ax5.set_xlabel("Reading Time (s)")
    ax5.set_ylabel("Frequency")
    ax5.grid(True, linestyle="--", alpha=0.5)

    # --- Panel 6: Histogram of Voting Reaction Times (Excludes Final Vote) ---
    ax6 = axes[1, 2]
    if statement_voting_times:
        ax6.hist(
            statement_voting_times, bins=6, color="skyblue", edgecolor="black"
        )
    ax6.set_title("Histogram of Voting Reaction Times")
    ax6.set_xlabel("Voting Time (s)")
    ax6.set_ylabel("Frequency")
    ax6.grid(True, linestyle="--", alpha=0.5)

    # Hide unused subplots in 3x3 grid
    axes[2, 0].axis("off")
    axes[2, 1].axis("off")
    axes[2, 2].axis("off")

    plt.tight_layout(rect=[0, 0, 1, 0.95])
    output_plot_path = os.path.join(folder_path, "session_analysis.png")
    plt.savefig(output_plot_path, dpi=300)
    plt.close()
    print(f"Saved analysis plot to: {output_plot_path}\n")


# ==========================================
# SCRIPT EXECUTION
# ==========================================
if __name__ == "__main__":
    if len(sys.argv) > 1:
        target_folder = sys.argv[1]
        if os.path.exists(target_folder):
            analyze_participant(target_folder)
        else:
            print(f"Error: Folder '{target_folder}' does not exist.")
    else:
        all_folders = [
            f
            for f in os.listdir(".")
            if os.path.isdir(f) and (f.startswith("P") or f.startswith("P_"))
        ]
        if not all_folders:
            print(
                "No participant folders found starting with 'P' or 'P_' in this directory."
            )
        else:
            for folder in sorted(all_folders):
                analyze_participant(folder)