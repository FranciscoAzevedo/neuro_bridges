import glob
import os
import random
import sys
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf


def find_csv_file(folder_path, pattern):
    """Finds a CSV file matching a pattern inside a participant folder."""
    matches = glob.glob(os.path.join(folder_path, f"*{pattern}*.csv"))
    if matches:
        return matches[0]
    return None


def run_group_analysis(output_filename="group_analysis.png"):
    # ----------------------------------------------------
    # LOCATE PARTICIPANT FOLDERS
    # ----------------------------------------------------
    participant_folders = sorted(
        [
            f
            for f in os.listdir(".")
            if os.path.isdir(f) and (f.startswith("P") or f.startswith("P_"))
        ]
    )

    if not participant_folders:
        print("Error: No participant folders found starting with 'P' or 'P_'.")
        return

    print(f"Found {len(participant_folders)} participant(s): {participant_folders}")

    all_scores = []
    all_reading_times = []
    all_voting_times = []
    model_rows = []

    # ----------------------------------------------------
    # LOAD AND AGGREGATE DATA
    # ----------------------------------------------------
    for folder in participant_folders:
        reading_file = find_csv_file(folder, "reading_times")
        voting_file = find_csv_file(folder, "voting_times")

        # Load Reading Times
        r_times = []
        if reading_file and os.path.exists(reading_file):
            with open(reading_file, "r") as f:
                lines = [line.strip().split(",") for line in f if line.strip()]
                if len(lines) >= 2:
                    r_times = [float(x) for x in lines[1][:10]]

        # Load Voting Times & Scores (10 statement evaluations + 11th overall evaluation)
        v_times = []
        v_scores = []
        if voting_file and os.path.exists(voting_file):
            with open(voting_file, "r") as f:
                lines = [line.strip().split(",") for line in f if line.strip()]
                if len(lines) >= 3:
                    v_times = [float(x) for x in lines[1]]
                    v_scores = [int(float(x)) for x in lines[2]]

        # Ensure participant completed all 10 statements and final evaluation
        if len(r_times) >= 10 and len(v_scores) >= 11:
            stmt_scores = v_scores[:10]
            y_final = v_scores[10]

            all_reading_times.append(r_times[:10])
            all_voting_times.append(v_times[:10])
            all_scores.append(stmt_scores)

            # Feature Engineering: Predictors relative to Subject Mean Score (S_mean)
            s_mean = np.mean(stmt_scores)
            delta_peak = max(stmt_scores) - s_mean  # Delta S_peak = Peak - Mean
            delta_end = stmt_scores[-1] - s_mean    # Delta S_end = End - Mean

            model_rows.append(
                {
                    "Subject": folder,
                    "Y_final": y_final,
                    "Delta_peak": delta_peak,
                    "Delta_end": delta_end,
                    "S_mean": s_mean,
                }
            )
        else:
            print(f"Warning: Incomplete data in folder '{folder}'. Skipping...")

    n_valid = len(all_scores)
    if n_valid == 0:
        print("Error: No valid participant data available for analysis.")
        return

    print(f"Successfully processed data for {n_valid} participant(s).\n")

    all_scores_np = np.array(all_scores)
    all_reading_np = np.array(all_reading_times)
    all_voting_np = np.array(all_voting_times)
    df_model = pd.DataFrame(model_rows)

    # ----------------------------------------------------
    # FIT LINEAR MODEL
    # Formula: Y_final ~ Delta_peak + Delta_end + S_mean
    # ----------------------------------------------------
    try:
        model = smf.ols("Y_final ~ Delta_peak + Delta_end + S_mean", data=df_model).fit()
        params = model.params
        conf_ints = model.conf_int()
        pvalues = model.pvalues
        r2 = model.rsquared
        y_pred = model.predict(df_model)
        has_model = True
    except Exception as e:
        print(f"Warning: Could not fit regression model due to: {e}")
        has_model = False

    # ----------------------------------------------------
    # GENERATE GROUP PLOTS (2x3 Grid Layout)
    # ----------------------------------------------------
    fig, axes = plt.subplots(2, 3, figsize=(19, 12))
    fig.suptitle(
        f"Group Level Analysis & Predictive Modeling (N = {n_valid} Participants)",
        fontsize=18,
        fontweight="bold",
    )

    trials = np.arange(1, 11)

    # --- Panel 1: Pooled Voting Time Split (<= 5 vs > 5) ---
    ax1 = axes[0, 0]
    flat_scores = all_scores_np.flatten()
    flat_vtimes = all_voting_np.flatten()

    low_split = flat_vtimes[flat_scores <= 5]
    high_split = flat_vtimes[flat_scores > 5]

    x_low = [0 + random.uniform(-0.08, 0.08) for _ in low_split]
    x_high = [1 + random.uniform(-0.08, 0.08) for _ in high_split]

    ax1.scatter(x_low, low_split, color="red", alpha=0.7, s=50, label="Score ≤ 5")
    ax1.scatter(x_high, high_split, color="green", alpha=0.7, s=50, label="Score > 5")

    max_vtime = max(flat_vtimes) if len(flat_vtimes) > 0 else 1
    ax1.text(0, max_vtime * 1.02, f"n = {len(low_split)}", ha="center", color="red", fontweight="bold")
    ax1.text(1, max_vtime * 1.02, f"n = {len(high_split)}", ha="center", color="green", fontweight="bold")

    ax1.set_xticks([0, 1])
    ax1.set_xticklabels(["Score ≤ 5", "Score > 5"])
    ax1.set_ylabel("Voting Reaction Time (s)")
    ax1.set_title("Pooled Voting Time Split by Score")
    ax1.set_ylim(0, max_vtime * 1.1)
    ax1.grid(True, linestyle="--", alpha=0.5)

    # --- Panel 2: Voting Scores Across Statements ---
    ax2 = axes[0, 1]
    for idx, p_scores in enumerate(all_scores_np):
        ax2.plot(
            trials,
            p_scores,
            color="gray",
            alpha=0.4,
            linewidth=1.2,
            label="Individual" if idx == 0 else "",
        )

    mean_scores = np.mean(all_scores_np, axis=0)
    ax2.plot(
        trials,
        mean_scores,
        color="black",
        linewidth=3.5,
        marker="o",
        markersize=7,
        label="Group Mean",
    )

    ax2.set_xticks(trials)
    ax2.set_title("Voting Scores Across Statements")
    ax2.set_xlabel("Statement Trial")
    ax2.set_ylabel("Score (0-10)")
    ax2.set_ylim(-0.5, 10.5)
    ax2.set_yticks(range(0, 11))
    ax2.grid(True, linestyle="--", alpha=0.5)
    ax2.legend(loc="upper right")

    # --- Panel 3: Fixed Effects Coefficients (Forest Plot) ---
    ax3 = axes[0, 2]
    if has_model:
        feature_labels = {
            "Intercept": r"Intercept ($\beta_0$)",
            "Delta_peak": r"Peak - Mean ($\Delta S_{\mathrm{peak}}$)",
            "Delta_end": r"End - Mean ($\Delta S_{\mathrm{end}}$)",
            "S_mean": r"Mean Score ($\bar{S}$)",
        }
        param_keys = [k for k in params.index if k in feature_labels]
        y_positions = np.arange(len(param_keys))

        for idx, key in enumerate(param_keys):
            beta = params[key]
            ci_low, ci_high = conf_ints.loc[key]
            pval = pvalues[key]

            color = "darkgreen" if pval < 0.05 else "navy"
            ax3.errorbar(
                beta,
                idx,
                xerr=[[beta - ci_low], [ci_high - beta]],
                fmt="o",
                color=color,
                ecolor=color,
                elv=2,
                capsize=5,
                markersize=7,
            )

            p_text = f"p={pval:.3f}" if pval >= 0.001 else "p<0.001"
            ax3.text(
                ci_high + 0.05,
                idx,
                f"β={beta:.2f} ({p_text})",
                va="center",
                fontsize=9,
                color=color,
            )

        ax3.axvline(0, color="black", linestyle="--", alpha=0.7)
        ax3.set_yticks(y_positions)
        ax3.set_yticklabels([feature_labels[k] for k in param_keys])
        ax3.set_xlabel(r"Coefficient Estimate ($\beta \pm 95\%$ CI)")
        ax3.set_title("Model Fixed Effects")
        ax3.grid(True, linestyle="--", alpha=0.5)
    else:
        ax3.text(0.5, 0.5, "Insufficient data/variance\nfor regression fit", ha="center", va="center")

    # --- Panel 4: Observed vs. Predicted Final Score ---
    ax4 = axes[1, 0]
    if has_model:
        ax4.scatter(
            df_model["Y_final"],
            y_pred,
            color="purple",
            s=60,
            alpha=0.8,
            edgecolors="black",
            zorder=3,
        )

        min_val = min(df_model["Y_final"].min(), y_pred.min()) - 0.5
        max_val = max(df_model["Y_final"].max(), y_pred.max()) + 0.5
        ax4.plot([min_val, max_val], [min_val, max_val], "k--", alpha=0.6, label="Identity (y = x)")

        ax4.text(
            0.05,
            0.90,
            f"$R^2 = {r2:.3f}$",
            transform=ax4.transAxes,
            fontsize=12,
            fontweight="bold",
            bbox=dict(boxstyle="round,pad=0.3", facecolor="white", edgecolor="gray"),
        )

        ax4.set_xlabel(r"Observed Final Score ($Y_{\mathrm{final}}$)")
        ax4.set_ylabel(r"Predicted Final Score ($\hat{Y}_{\mathrm{final}}$)")
        ax4.set_title("Model Fit: Observed vs. Predicted")
        ax4.set_xlim(min_val, max_val)
        ax4.set_ylim(min_val, max_val)
        ax4.grid(True, linestyle="--", alpha=0.5)
        ax4.legend(loc="lower right")

    # --- Panel 5: Statement Reading Times Across Trials ---
    ax5 = axes[1, 1]
    for t_idx in range(10):
        t_num = t_idx + 1
        r_vals = all_reading_np[:, t_idx]
        x_jittered = [t_num + random.uniform(-0.12, 0.12) for _ in r_vals]
        ax5.scatter(
            x_jittered,
            r_vals,
            color="orange",
            alpha=0.7,
            s=45,
            edgecolors="darkorange",
            linewidths=0.5,
        )

    mean_reading = np.mean(all_reading_np, axis=0)
    ax5.plot(
        trials,
        mean_reading,
        color="darkred",
        linewidth=2.5,
        marker="s",
        markersize=6,
        label="Mean Reading Time",
    )

    ax5.set_xticks(trials)
    ax5.set_title("Statement Reading Times Across Trials")
    ax5.set_xlabel("Statement Trial")
    ax5.set_ylabel("Reading Time (s)")
    ax5.grid(True, linestyle="--", alpha=0.5)
    ax5.legend(loc="upper right")

    # --- Panel 6: Voting Reaction Times Across Trials ---
    ax6 = axes[1, 2]
    for t_idx in range(10):
        t_num = t_idx + 1
        v_vals = all_voting_np[:, t_idx]
        x_jittered = [t_num + random.uniform(-0.12, 0.12) for _ in v_vals]
        ax6.scatter(
            x_jittered,
            v_vals,
            color="skyblue",
            alpha=0.7,
            s=45,
            edgecolors="dodgerblue",
            linewidths=0.5,
        )

    mean_voting = np.mean(all_voting_np, axis=0)
    ax6.plot(
        trials,
        mean_voting,
        color="navy",
        linewidth=2.5,
        marker="s",
        markersize=6,
        label="Mean Voting Time",
    )

    ax6.set_xticks(trials)
    ax6.set_title("Voting Reaction Times Across Trials")
    ax6.set_xlabel("Statement Trial")
    ax6.set_ylabel("Voting Reaction Time (s)")
    ax6.grid(True, linestyle="--", alpha=0.5)
    ax6.legend(loc="upper right")

    plt.tight_layout(rect=[0, 0, 1, 0.95])
    plt.savefig(output_filename, dpi=300)
    plt.close()
    print(f"Group analysis plot successfully generated and saved to '{output_filename}'!")


if __name__ == "__main__":
    run_group_analysis()